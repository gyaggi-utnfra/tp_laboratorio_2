using System;
using System.IO;
using Archivos;
using ClasesInstanciables;
using Excepciones;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Test
{
  [TestClass]
  public class UnitTest1
  {
    [TestMethod]
    [ExpectedException(typeof(FileNotFoundException))]
    public void TestFileNotFoundException()
    {
      Texto txt = new Texto();
      string path = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
      string res;
      try
      {
        txt.Leer(path, out res);
      }
      catch (ArchivosException)
      {
        throw new FileNotFoundException();
      }
    }


    [TestMethod]
    [ExpectedException(typeof(DniInvalidoException))]
    public void TestDniInvalidoException()
    {
      Alumno alumno = null;

      try
      {
        alumno = new Alumno(4, "Miguel", "Hernandez",
                   "922aaaa223123", ClasesAbstractas.Persona.ENacionalidad.Argentino,
                   Universidad.EClases.SPD);
      }
      catch (DniInvalidoException)
      {
        throw new DniInvalidoException("DNI con caracteres no numericos");
      }
    }

    [TestMethod]
    public void TestDni()
    {
      string dni = "37537463";
      Alumno alumno = new Alumno(1, "Rogelio", "Aguas",
           "38537463", ClasesAbstractas.Persona.ENacionalidad.Argentino,
           Universidad.EClases.Programacion);

      Assert.AreNotEqual(int.Parse(dni), alumno.DNI);
    }


    [TestMethod]
    public void InstanciarListasUniversidad()
    {
      Universidad miUniversidad = new Universidad();

      Assert.IsNotNull(miUniversidad.Instructores);
      Assert.IsNotNull(miUniversidad.Jornadas);
      Assert.IsNotNull(miUniversidad.Alumnos);
    }

  }
}
