using Archivos;
using System;
using System.Collections.Generic;
using System.Text;
using ClasesInstanciables;

namespace ClasesInstanciables
{
  public class Jornada
  {

    #region atributos
    private List<Alumno> alumnos;
    private Universidad.EClases clase;
    private Profesor instructor;

    #endregion

    #region Propiedades
    public List<Alumno> Alumnos
    {
      get
      {
        return this.alumnos;
      }
      set
      {
        this.alumnos = value;
      }
    }

    public Universidad.EClases Clase
    {
      get
      {
        return this.clase;
      }
      set
      {
        this.clase = value;
      }
    }
    public Profesor Instructor
    {
      get
      {
        return this.instructor;
      }
      set
      {
        this.instructor = value;
      }
    }
    #endregion

    #region Constructores
    /// <summary>
    /// Constructor privado que instancia la lista de alumnos.
    /// </summary>
    private Jornada()
    {
      this.alumnos = new List<Alumno>();
    }

    /// <summary>
    /// Constructor de Jornada. 
    /// Llama al constructor por defecto.
    /// </summary>
    /// <param name="clase">Clase que toma</param>
    /// <param name="instructor">Profesor que da la clase.</param>
    public Jornada(Universidad.EClases clase, Profesor instructor) : this()
    {
      this.Instructor = instructor;
      this.Clase = clase;
    }
    #endregion

    #region Metodos
    /// <summary>
    /// Metodo que guarda los datos de Jornada. 
    /// Alojandolos en el archivo "Jornada.txt"
    /// </summary>
    /// <param name="jornada">Jornada</param>
    /// <returns></returns>
    public static bool Guardar(Jornada jornada)
    {
      Texto texto = new Texto();
      string path = AppDomain.CurrentDomain.BaseDirectory + "Jornada.txt";
      string txtDato = jornada.ToString();
      return texto.Guardar(path, txtDato);
    }
    /// <summary>
    /// Metodo utilizado para leer el archivo "Jornada.txt"
    /// retornando los datos en una cadena de caracteres.
    /// </summary>
    /// <returns>"Retorno" string</returns>
    public string Leer()
    {
      string retorno;
      Texto texto = new Texto();
      string path = AppDomain.CurrentDomain.BaseDirectory + "Jornada.txt";
      texto.Leer(path, out retorno);
      return retorno;
    }

    /// <summary>
    /// Metodo utilizado para retornar los datos de la Jornada.
    /// </summary>
    /// <returns>Cadena de caracteres con toda la informacion de la jornada</returns>
    public override string ToString()
    {
      StringBuilder sb = new StringBuilder();


      sb.Append("Clase: ");
      sb.Append(this.Clase);
      sb.Append(" Por ");
      sb.AppendLine(this.Instructor.ToString());
      sb.AppendLine("Alumnos: ");

      foreach (Alumno a in this.Alumnos)
      {
        sb.AppendLine(a.ToString());
      }

      sb.AppendLine("<------------------------------------------------------->");
      return sb.ToString();
    }

    #endregion

    #region Sobrecarga de Operadores
    /// <summary>
    /// Verifica que el alumno sea parte de la jornada. 
    /// Retornando true en caso de ser verdadero.
    /// </summary>
    /// <param name="j">Jornada</param>
    /// <param name="a">Alumno</param>
    /// <returns></returns>
    public static bool operator ==(Jornada j, Alumno a)
    {
      return j.Alumnos.Contains(a);
    }

    /// <summary>
    /// Verifica que el alumno no sea parte de la jornada.
    /// Retornando lo contrario del metodo ==
    /// </summary>
    /// <param name="j">Jornada</param>
    /// <param name="a">Alumno</param>
    /// <returns></returns>
    public static bool operator !=(Jornada j, Alumno a)
    {
      return !(j == a);
    }
    /// <summary>
    /// Metodo utilizado para agregar un alumno a la jornada.
    /// Solo se agregara al alumno si no era parte de la jornada.
    /// </summary>
    /// <param name="j">Jornada</param>
    /// <param name="a">Alumno</param>
    /// <returns></returns>
    public static Jornada operator +(Jornada j, Alumno a)
    {
      if (j != a)
      {
        j.Alumnos.Add(a);
      }
      return j;
    }

    #endregion

  }

}
