﻿using System;
using System.IO;
using Archivos;
using ClasesInstanciables;
using Excepciones;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Test
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestDnivalido()
        {
            Alumno alumno;

            string dniValido = "37537463";

            alumno = new Alumno(1, "Marilin", "Monroe",
                dniValido, ClasesAbstractas.Persona.ENacionalidad.Argentino,
                Universidad.EClases.SPD);

            Assert.AreEqual(int.Parse(dniValido), alumno.DNI);
        }


        [TestMethod]
        [ExpectedException(typeof(DniInvalidoException))]
        public void TestDniInvalidoException()
        {
            Alumno alumno = null;

            try
            {
                alumno = new Alumno(4, "Pol", "LaCarne",
                           "5552aa2213", ClasesAbstractas.Persona.ENacionalidad.Argentino,
                           Universidad.EClases.SPD);
            }
            catch (DniInvalidoException)
            {
                throw new DniInvalidoException("DNI con caracteres no numericos");
            }
        }

        [TestMethod]
        public void TestDni()
        {
            string dni = "treintayochomillonesquinientoscincuentamiltreintayuno";
            Alumno alumno = new Alumno(1, "Rogelio", "Aguas","38550030", ClasesAbstractas.Persona.ENacionalidad.Argentino,
                 Universidad.EClases.Programacion);

            Assert.AreNotEqual(dni, alumno.DNI);
        }


        [TestMethod]
        public void InstanciarListasUniversidad()
        {
            Universidad miUniversidad = new Universidad();

            Assert.IsNotNull(miUniversidad.Instructores);
            Assert.IsNotNull(miUniversidad.Jornadas);
            Assert.IsNotNull(miUniversidad.Alumnos);
        }

    }
}