using Excepciones;
using System;
using System.Text;
using System.Xml;
using System.Xml.Serialization;

namespace Archivos
{
    public class Xml<T> : IArchivo<T>
    {
    //Clase que implementa interface de archivos.
    //Clase que se utiliza para Guardar y Leer archivos en formato XML.

    #region Metodos
    public bool Guardar(string archivo, T datos)
        {
            XmlTextWriter wri = null;
            XmlSerializer serializer;     

            try
            {
                wri = new XmlTextWriter(archivo, Encoding.UTF8);
                serializer = new XmlSerializer(typeof(T));
                serializer.Serialize(wri, datos);
            }
            catch (Exception)
            {
                throw new ArchivosException();
            }
            finally
            {
                wri.Close();
            }
            return true;
        }

        public bool Leer(string archivo, out T datos)
        {
            XmlTextReader reader = null;
            XmlSerializer serializer;
            try
            {

                reader = new XmlTextReader(archivo);
                serializer = new XmlSerializer(typeof(T));
                datos = (T)serializer.Deserialize(reader);

            }
            catch (Exception)
            {
                throw new ArchivosException();
            }
            finally
            {
                reader.Close();
            }
            return true;

        }
    #endregion

  }
}
