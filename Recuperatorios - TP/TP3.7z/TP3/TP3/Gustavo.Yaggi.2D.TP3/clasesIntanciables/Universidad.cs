using Archivos;
using Excepciones;
using System;
using System.Collections.Generic;
using System.Text;

namespace ClasesInstanciables
{
  public class Universidad
  {
    public enum EClases
    {
      Programacion, Laboratorio, Legislacion, SPD
    }

    #region Atributos
    private List<Alumno> alumnos;
    private List<Jornada> jornada;
    private List<Profesor> profesores;
    #endregion

    #region Propiedades
    public List<Alumno> Alumnos
    {
      get
      {
        return this.alumnos;
      }
      set
      {
        this.alumnos = value;
      }
    }
    public List<Profesor> Instructores
    {
      get
      {
        return this.profesores;
      }
      set
      {
        this.profesores = value;
      }
    }
    public List<Jornada> Jornadas
    {
      get
      {
        return this.jornada;
      }
      set
      {
        this.jornada = value;
      }
    }
    public Jornada this[int i]
    {
      get
      {
        return this.jornada[i];
      }
      set
      {
        this.jornada[i] = value;
      }
    }
    #endregion

    #region Constructor
    /// <summary>
    /// Constructor por defecto de universidad que instancia todas las listas.
    /// </summary>
    public Universidad()
    {
      this.alumnos = new List<Alumno>();
      this.profesores = new List<Profesor>();
      this.jornada = new List<Jornada>();
    }
    #endregion

    #region Metodos
    /// <summary>
    /// Metodo utilizado para guardar los datos de universidad en formato XML
    /// </summary>
    /// <param name="uni">Universidad</param>
    /// <returns></returns>
    public static bool Guardar(Universidad uni)
    {
      Xml<Universidad> xml = new Xml<Universidad>();
      string path = AppDomain.CurrentDomain.BaseDirectory + "Universidad.xml";
      return xml.Guardar(path, uni);
    }

    /// <summary>
    /// Metodo utilizado para mostrar los datos de la Universidad.
    /// </summary>
    /// <param name="uni">Universidad</param>
    /// <returns></returns>
    private static string MostrarDatos(Universidad uni)
    {
      StringBuilder sb = new StringBuilder();

      sb.AppendLine("JORNADA: ");

      foreach (Jornada j in uni.jornada)
      {
        sb.AppendLine(j.ToString());
      }

      return sb.ToString();
    }

    /// <summary>
    /// Metodo utilizado para invocar al metodo "MostrarDatos" de Universidad
    /// </summary>
    /// <returns></returns>
    public override string ToString()
    {
      return MostrarDatos(this);
    }
    #endregion

    #region Sobrecarga de Operadores

    /// <summary>
    /// Agrega al profesor verificando que no este previamente cargado.
    /// </summary>
    /// <param name="g">Universidad</param>
    /// <param name="i">Profesor</param>
    /// <returns></returns>
    public static Universidad operator +(Universidad g, Profesor i)
    {
      if (g != i)
      {
        g.Instructores.Add(i);
      }
      return g;
    }

    /// <summary>
    /// Agrega al alumno verificando que no este previamente cargado.
    /// </summary>
    /// <param name="u"></param>
    /// <param name="a"></param>
    /// <returns></returns>
    public static Universidad operator +(Universidad u, Alumno a)
    {
      if (u != a)
      {
        u.Alumnos.Add(a);
      }
      else
      {
        throw new AlumnoRepetidoException();
      }
      return u;
    }
    public static Universidad operator +(Universidad g, EClases clase)
    {
      Profesor miProfesor;
      try
      {
        miProfesor = (g == clase);
      }
      catch (Exception e)
      {
        throw e;
      }
      Jornada j = new Jornada(clase, miProfesor);
      foreach (Alumno al in g.alumnos)
      {
        if (al == clase)
        {
          j += al;
        }
      }
      g.Jornadas.Add(j);
      return g;
    }
    /// <summary>
    /// Un Universidad será igual a un Alumno si el mismo está inscripto en él.
    /// </summary>
    /// <param name="g">Universidad</param>
    /// <param name="a"></param>
    /// <returns></returns>
    public static bool operator ==(Universidad g, Alumno a)
    {
      foreach (Alumno item in g.Alumnos)
      {
        if (item == a)
        {
          return true;
        }
      }

      return false;
    }

    /// <summary>
    /// Un Universidad será igual a un Profesor si el mismo está dando clases en él.
    /// </summary>
    /// <param name="g">Universidad</param>
    /// <param name="i">Profesor</param>
    /// <returns></returns>
    public static bool operator ==(Universidad g, Profesor i)
    {
      return (g.Instructores.Contains(i));
    }

    /// <summary>
    /// Retorna el profesor que tome la clase.
    /// En caso de no encontrar profesor lanza la excepcion "SinProfesor"
    /// </summary>
    /// <param name="u">Univerisdad</param>
    /// <param name="clase">Clase</param>
    /// <returns></returns>
    public static Profesor operator ==(Universidad u, EClases clase)
    {
      foreach (Profesor i in u.Instructores)
      {
        if (i == clase)
        {
          return i;
        }
      }
      throw new SinProfesorException();
    }

    public static bool operator !=(Universidad g, Alumno a)
    {
      return !(g == a);
    }
    public static bool operator !=(Universidad g, Profesor i)
    {
      return !(g == i);
    }

    /// <summary>
    /// retornará el primer Profesor que no pueda dar la clase.
    /// </summary>
    /// <param name="u">Universidad</param>
    /// <param name="clase">Clase</param>
    /// <returns></returns>
    public static Profesor operator !=(Universidad u, EClases clase)
    {
      foreach (Jornada j in u.Jornadas)
      {
        if (j.Clase != clase)
        {
          return j.Instructor;
        }
      }
      throw new SinProfesorException();
    }
    #endregion

  }
}
