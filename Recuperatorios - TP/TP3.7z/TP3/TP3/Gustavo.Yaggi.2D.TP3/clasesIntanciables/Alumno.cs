using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClasesInstanciables;
using ClasesAbstractas;

namespace ClasesInstanciables
{

  public sealed class Alumno : Universitario
  {

    /// <summary>
    /// Enumerado "Estado de la cuenta del alumno"
    /// </summary>
    public enum EEstadoCuenta
    {
      AlDia, Deudor, Becado
    }

    #region Atributos
    private Universidad.EClases claseQueToma;
    private EEstadoCuenta estadoCuenta;
    #endregion

    #region Constructores
    /// <summary>
    /// Constructor por defecto de Alumno, utilizado por archivos.
    /// </summary>
    public Alumno()
    {
    }

    public Alumno(int id, string nombre, string apellido, string dni, ENacionalidad nacionalidad, Universidad.EClases claseQueToma) : base(id, nombre, apellido, dni, nacionalidad)
    {
      this.claseQueToma = claseQueToma;
    }
    public Alumno(int id, string nombre, string apellido, string dni, ENacionalidad nacionalidad, Universidad.EClases claseQueToma, EEstadoCuenta estadoCuenta)
        : this(id, nombre, apellido, dni, nacionalidad, claseQueToma)
    {
      this.estadoCuenta = estadoCuenta;
    }
    #endregion

    #region Sobrecarga de operadores
    /// <summary>
    /// Un Alumno será igual a un EClase si toma esa clase y su estado de cuenta no es Deudor.
    /// </summary>
    /// <param name="a">Alumno</param>
    /// <param name="clase">Clase que toma</param>
    /// <returns></returns>
    public static bool operator ==(Alumno a, Universidad.EClases clase)
    {
      return (a.claseQueToma == clase && a.estadoCuenta != EEstadoCuenta.Deudor);
    }

    /// <summary>
    /// Un Alumno no será igual a un EClase si no toma esa clase y su estado de cuenta es Deudor.
    /// </summary>
    /// <param name="a">Alumno</param>
    /// <param name="clase">Clase que toma</param>
    /// <returns></returns>
    public static bool operator !=(Alumno a, Universidad.EClases clase)
    {
      return a.claseQueToma != clase;
    }
    #endregion

    #region Metodos
    /// <summary>
    /// Metodo utilizado para mostrar la clase que toma el alumno.
    /// </summary>
    /// <returns>string</returns>
    protected override string ParticiparEnClase()
    {
      return "TOMA CLASE DE " + this.claseQueToma.ToString();
    }
    /// <summary>
    /// Metodo utilizado para exponer los datos del alumno.
    /// </summary>
    /// <returns>String</returns>
    protected override string MostrarDatos()
    {
      StringBuilder retorno = new StringBuilder();

      retorno.AppendLine(base.MostrarDatos());
      retorno.AppendLine("ESTADO DE CUENTA: " + (this.estadoCuenta == EEstadoCuenta.AlDia ? "Cuota al día" : this.estadoCuenta.ToString()));
      retorno.AppendLine(this.ParticiparEnClase());

      return retorno.ToString();
    }
    /// <summary>
    /// Metodo utilizado para poder llamar al metodo "MostrarDatos" de la clase Alumno.
    /// </summary>
    /// <returns>String</returns>
    public override string ToString()
    {
      return this.MostrarDatos();
    }
    #endregion

  }
}
