using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Numero
    {


        private double numero;

        public double SetNumero { set { this.numero = ValidarNumero(value.ToString()); } }


        public double GetNumero()
        {
           return this.numero;
        }

        /// <summary>
        /// El constructor por defecto el inicializará el atributo numero en 0 
        /// </summary>
        public Numero()
        {
            this.numero = 0;
        }

        /// <summary>
        ///  El constructor recibirá un string que validará y cargará en el atributo número 
        /// </summary>
        /// <param name="numero"></param>
        public Numero(string numero)
        {
            SetNumero = Double.Parse(numero);
        }

        /// <summary>
        ///  El constructor recibirá un double que validará y cargará en el atributo número 
        /// </summary>
        /// <param name="numero"></param>
        public Numero(double numero)
        {
            this.numero = numero;
        }

        /// <summary>
        /// Metodo que validara el numero retornara un double. 0 en caso de no poder convertirlo a double.
        /// </summary>
        /// <param name="NumeroString"></param>
        /// <returns></returns>
        private static double ValidarNumero(string NumeroString)
        {
            double numero = 0;

            if (double.TryParse(NumeroString, out numero) != true)
            {
                return 0;
            }

            else
            {
                return numero;
            }
        }

        /// <summary>
        /// Metodolo utilizado para convertir de binario a decimal.
        /// </summary>
        /// <param name="binario"></param>
        /// <returns></returns>
        public string BinarioDecimal(string binario)
        {
            foreach (var c in binario)
            {
                if (c != '0' && c != '1')
                {
                    return "Valor Invalido";
                }
            }
            return Convert.ToInt64(binario, 2).ToString();
        }
        /// <summary>
        /// Metodo utilizado para llamar al conversor de decimal a binario.
        /// </summary>
        /// <param name="numero"></param>
        /// <returns></returns>
        public string DecimalBinario(double numero)
        {
            return DecimalBinario(numero.ToString());
        }

        /// <summary>
        /// Metodo utilizado para convertir de decimal a binario.
        /// </summary>
        /// <param name="numero"></param>
        /// <returns></returns>
        public string DecimalBinario(string numero)
        {
            if (ValidarNumero(numero) > 0)
            {
                double numeroD = double.Parse(numero);
                string binario = "";
                if (numeroD > 0)
                {
                    while (numeroD > 0)
                    {
                        if (numeroD % 2 == 0)
                        {
                            binario = "0" + binario;
                        }
                        else
                        {
                            binario = "1" + binario;
                        }
                        numeroD = (int)(numeroD / 2);
                    }
                }
                else
                {
                    if (numeroD == 0)
                    {
                        binario = "0";
                    }
                }
                return binario;
            }
            else
            {
                return "Valor Invalido";
            }
        }

        #region Sobrecargar de operadores
        public static double operator -(Numero n1, Numero n2)
        {
            return n1.numero - n2.numero;
        }
        public static double operator *(Numero n1, Numero n2)
        {
            return n1.numero * n2.numero;
        }
        public static double operator /(Numero n1, Numero n2)
        {
            if (n2.numero != 0)
            {
                return n1.numero / n2.numero;
            }
            else
            {
                return 0;
            }
        }
        public static double operator +(Numero n1, Numero n2)
        {
            return n1.numero + n2.numero;
        }
        #endregion
    }
}
