using System;
using System.Collections.Generic;
using System.Text;
using ClasesInstanciables;
using ClasesAbstractas;

namespace ClasesInstanciables
{
  public sealed class Profesor : Universitario
  {

    #region Atributos
    private Queue<Universidad.EClases> clasesDelDia;
    private static Random random;
    #endregion

    #region Constructores
    /// <summary>
    /// Constructor statico que instancia el "random".
    /// </summary>
    static Profesor()
    {
      random = new Random();
    }
    /// <summary>
    /// Constructor privado que instancia el "random".
    /// </summary>
    private Profesor()
    {
      random = new Random();
    }

    public Profesor(int id, string nombre, string apellido, string dni, ENacionalidad nacionalidad) : base(id, nombre, apellido, dni, nacionalidad)
    {
      clasesDelDia = new Queue<Universidad.EClases>();
      _randomClases();
    }

    #endregion

    #region Metodos
    /// <summary>
    /// Metodo utilizado para mostrar los datos del profesor.
    /// </summary>
    /// <returns></returns>
    protected override string MostrarDatos()
    {
      StringBuilder sb = new StringBuilder();

      sb.Append(base.MostrarDatos());
      sb.Append(this.ParticiparEnClase());

      return sb.ToString();
    }
    /// <summary>
    /// Metodo utilizado para mostrar las clases que toma el profesor.
    /// </summary>
    /// <returns></returns>
    protected override string ParticiparEnClase()
    {
      StringBuilder sb = new StringBuilder();
      sb.AppendLine("CLASES DEL DIA: ");
      foreach (Universidad.EClases clase in this.clasesDelDia)
      {
        sb.AppendLine(clase.ToString());
      }
      return sb.ToString();
    }
    /// <summary>
    /// Metodo utilizado para invocar al metodo "Mostrardatos" de la clase profesor.
    /// </summary>
    /// <returns></returns>
    public override string ToString()
    {
      return this.MostrarDatos();
    }

   
    /// <summary>
    /// Metodo utilizado par asignar dos clases de manera aleatoria.
    /// </summary>
    private void _randomClases()
    {
      int contador = 0;
      while (contador < 2)
      {
        clasesDelDia.Enqueue((Universidad.EClases)random.Next(0, 3));
        contador++;
      }
    }
    #endregion

    #region Sobrecarga de operadores
    /// <summary>
    /// Un profesor sera igual a una clase, solo si es la clase que toma.
    /// </summary>
    /// <param name="i">Profesor</param>
    /// <param name="clase">Clase que toma</param>
    /// <returns></returns>
    public static bool operator ==(Profesor i, Universidad.EClases clase)
    {
      return i.clasesDelDia.Contains(clase);
    }
    public static bool operator !=(Profesor i, Universidad.EClases clase)
    {
      return !(i == clase);
    }
    #endregion

  }
}
