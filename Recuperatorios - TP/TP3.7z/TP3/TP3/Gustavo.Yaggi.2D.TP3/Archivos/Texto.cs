using Excepciones;
using System;
using System.IO;

namespace Archivos
{
    public class Texto : IArchivo<string>
    {
        //Clase Texto que implementa la interface de archivos.
        //En esta clase se pueden guardar y leer archivos de texto.

        #region Metodos Guardar y Leer
        public bool Guardar(string archivo, string datos)
        {
            StreamWriter sw = null;
            try
            {
                sw = new StreamWriter(archivo, true);
                sw.WriteLine(datos);
            }
            catch (Exception)
            {
                throw new ArchivosException();
            }
            finally
            {
                sw.Close();
            }
            return true;
        }
        public bool Leer(string archivo, out string datos)
        {
            StreamReader sw = null;
            try
            {
                sw = new StreamReader(archivo);
                datos = sw.ReadToEnd();
            }
            catch (ArchivosException)
            {
                throw new ArchivosException();
            }
            finally
            {
                try
                {
                    sw.Close();
                }
                catch (Exception)
                {


                }
            }
            return true;
        }
        #endregion
    
    }
}
