using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades;

namespace LaCalculadora
{
    public partial class Form1 : Form
    {
        private Numero numero1;
        private Numero numero2;
        private double resultado;
        private string operador;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnConvertirABinario_Click(object sender, EventArgs e)
        {
            Numero num = new Numero();
            lblResultado.Text = num.DecimalBinario(lblResultado.Text);
        }

        private void cmbOperacion_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.operador = Entidades.Calculadora.ValidarOperador(this.cmbOperacion.Text);
        }

        private void btnOperar_Click(object sender, EventArgs e)
        {
            this.resultado = Operar(this.numero1, this.numero2, this.operador);
            this.lblResultado.Text = this.resultado.ToString();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (this.txtNumero1.Text == "")
            {
                this.txtNumero1.Text = "0";
            }
            this.numero1 = new Numero(this.txtNumero1.Text);
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            if (this.txtNumero2.Text == "")
            {
                this.txtNumero2.Text = "0";
            }
            this.numero2 = new Numero(this.txtNumero2.Text);
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            this.txtNumero1.Clear();
            this.txtNumero2.Clear();
            this.cmbOperacion.Text = "+";
            this.lblResultado.Text = "";
        }

        public static double Operar(Numero numero1, Numero numero2, string operador)
        {
            return Calculadora.Operar(numero1, numero2, operador);
        }

        private void btnCerrar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnConvertirADecimal_Click(object sender, EventArgs e)
        {
            Numero num = new Numero();
            lblResultado.Text = num.BinarioDecimal(lblResultado.Text);
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
