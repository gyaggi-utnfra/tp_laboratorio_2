﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Calculadora
    {

        #region Metodos
        /// <summary>
        /// Metodo de clase que realiza la operacion. Y retorna un double
        /// </summary>
        /// <param name="numero1">Numero1</param>
        /// <param name="numero2">Numero2</param>
        /// <param name="operador">Operando</param>
        /// <returns></returns>
        public static double Operar(Numero num1, Numero num2, string operador)
        {
            operador = ValidarOperador(operador);
            double resultado = 0;
            switch (operador)
            {
                case "+":
                    resultado = num1 + num2;
                    break;
                case "-":
                    resultado = num1 - num2;
                    break;
                case "/":
                    resultado = num1 / num2;
                    break;
                case "*":
                    resultado = num1 * num2;
                    break;
            }

            return resultado;
        }

        /// <summary>
        /// Metodo que valida el operador, en caso que no sea un operador valido retorna +
        /// </summary>
        /// <param name="operador"></param>
        /// <returns></returns>
        public static string ValidarOperador(string operador)
        {
            if (operador == "+" || operador == "-" || operador == "*" || operador == "/")
            {
                return operador;
            }

            else
            {
                return "+";
            }
        }
        #endregion
    }
}
